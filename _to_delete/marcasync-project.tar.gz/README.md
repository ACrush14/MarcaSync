# MarcaSync

Protótipo funcional do fluxo de produto do MarcaSync — automação do processo de
registro de marcas junto ao INPI. Este repositório contém duas coisas:

- **`prototype.html`** — o protótipo standalone (HTML/CSS/JS puro, um arquivo só), o
  mesmo publicado como artifact durante a fase de validação de interface. Útil para
  abrir direto no navegador sem instalar nada.
- **`src/`** — o início real da aplicação em **Next.js 14 (App Router) + TypeScript +
  Tailwind**, com a mesma lógica portada para componentes tipados. É o ponto de partida
  para o desenvolvimento de verdade.

## Rodando localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000. Para checar tipos e build de produção antes de commitar:

```bash
npm run typecheck
npm run build
```

## O que já é funcional (não decorativo)

- **Colidência fonética real** (`src/lib/fonetica.ts`) — redução fonética simplificada
  para PT-BR + distância de Levenshtein, comparando a marca digitada contra uma base de
  exemplo (`src/lib/data.ts`). Isto é uma heurística deliberadamente pequena para provar
  a mecânica, **não** um Soundex/Metaphone validado — ver a seção "Próximos passos".
- **Inferência de classe NCL** (`src/lib/ncl.ts`) — mapeamento por palavra-chave de uma
  descrição em linguagem natural para uma das classes de Nice. Cobre 11 das 45 classes
  reais, como prova de conceito.
- **Painel de acompanhamento** (`src/components/PainelStep.tsx`) — linha do tempo do
  processo com datas calculadas a partir de hoje, contador de prazo de oposição (60
  dias, Art. 158 da LPI) e simulação interativa de um alerta de oposição de terceiro.

## O que é intencionalmente falso (e por quê)

Nada aqui fala com o INPI de verdade. A base de marcas (`BASE_MARCAS`), o protocolo
gerado e o histórico de leituras da RPI são dados de exemplo fixos no código. Isso é
proposital: o objetivo desta fase era validar a **interface e a mecânica do produto**
antes de gastar esforço de engenharia em integração externa — inclusive porque a
integração real tem pendências que precisam ser resolvidas primeiro, não puladas.

## Próximos passos (nesta ordem)

1. **Trocar a base fixa pelos Dados Abertos do INPI** (dadosabertos.inpi.gov.br / RPI em
   dados.gov.br) — ver `src/lib/data.ts`. Baixar uma amostra real, documentar o schema e
   escrever o parser antes de tocar em qualquer coisa que envolva scraping de HTML.
2. **Revisar o algoritmo fonético com alguém que entenda fonologia do português** — a
   versão atual é uma heurística de demonstração, não um algoritmo validado
   linguisticamente nem testado contra decisões reais de indeferimento do INPI.
3. **Desenhar o fluxo de procuração eletrônica** para peticionamento — nunca capturar ou
   armazenar credenciais gov.br de terceiros. O caminho correto é o cliente cadastrar o
   MarcaSync como procurador dentro do e-Marcas.
4. **Persistência real** — hoje todo o estado é `useState` em memória, perdido a cada
   reload. Entra banco de dados (Postgres) e API assim que houver dado real para
   guardar.

## Estrutura

```
src/
  app/
    layout.tsx      — fontes (next/font/google), metadata, shell HTML
    page.tsx         — monta <MarcaSyncApp />
    globals.css       — tokens de design (cores claro/escuro, tipografia) + estilos
  components/
    MarcaSyncApp.tsx — orquestrador: estado do wizard (etapa, marca, análise, plano...)
    Stepper.tsx       — navegação entre etapas, com trava de progresso
    ConsultaStep.tsx  — formulário de entrada
    LoadingStep.tsx   — checklist animado da análise
    ResultadoStep.tsx — resumo de risco, tabela de colidência
    WaveCanvas.tsx     — visualização da assinatura fonética (canvas)
    PlanoStep.tsx      — setup + monitoramento, com toggle funcional
    PainelStep.tsx     — timeline do processo + log de monitoramento da RPI
  lib/
    fonetica.ts   — algoritmo de colidência fonética + Levenshtein
    ncl.ts         — inferência de classe NCL + rótulos
    data.ts        — base de marcas de exemplo
    analysis.ts    — junta fonética + NCL num único resultado de análise
    types.ts        — tipos compartilhados
```
